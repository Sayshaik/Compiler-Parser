
public class A3Scanner {

}
