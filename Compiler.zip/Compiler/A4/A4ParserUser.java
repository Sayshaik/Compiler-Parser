import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;

class A4ParserUser{
    public static void main (String[] args) throws Exception{
        File inputFile = new File ("A4.input") ;
        A4Parser parser = new A4Parser(new A4Scanner(new FileInputStream ( inputFile )));

        String result;
        if(args.length > 0)
            result = (String) parser. debug_parse () . value ;
        else 
            result = (String) parser.parse().value;
        FileWriter fw =new FileWriter (new File("A4.java"));
        fw.write(result);
        fw.close();
    }
}
