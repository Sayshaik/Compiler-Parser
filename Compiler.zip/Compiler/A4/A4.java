package Assignment4;
import java.io.*;

public class A4 
{
	static BufferedReader _br;
	static BufferedWriter _bw;
	static double f2 (double x, double y) throws Exception
{
double z;
z = x*x - y*y;
return z;
}
public static void main(String[] args) throws Exception
{
int x;
_br = new BufferedReader(new FileReader("A41.input"));
x = new Integer(_br.readLine()).intValue();
int y;
_br = new BufferedReader(new FileReader("A42.input"));
y = new Integer(_br.readLine()).intValue();
double z;
z = f2(x, y) + f2(y, x)*0.5;
_bw = new BufferedWriter(new FileWriter("A4.output"));
_bw.write(z + "");
_bw.flush();
if(z == x)
{
_bw = new BufferedWriter(new FileWriter("A4.output"));
_bw.write(z + 4*x*y + "");
_bw.flush();
}
}
}