package Assignment2;
import java.io.*;

public class A2 {
    public static void main(String[] args) throws IOException {
        FileInputStream inputFile = new FileInputStream(new File("A2.input"));
        A2Lexer lexer = new A2Lexer(inputFile);

        lexer.yylex(); 

        FileWriter fw = new FileWriter("A2.output");
        fw.write("numbers: " + String.valueOf(lexer.NumberOfIntegersOrRealNumbers) + "\n");
        fw.write("comments: " + String.valueOf(lexer.NumberOfComments) + "\n");
        fw.write("lines: " + String.valueOf(lexer.NumberOfLines) + "\n");
        fw.write("quotedString: " + String.valueOf(lexer.NumberOfQuotedStrings) + "\n");
        fw.write("identifiers: " + String.valueOf(lexer.NumberOfIdentifiers) + "\n");
        fw.write("keywords: " + String.valueOf(lexer.keywordCount) + "\n");
        fw.close(); 
    }
}