import java.io.*;
import java.util.ArrayList;

public class A5 {
    static int pointer = -1;
    static ArrayList tokens = new ArrayList(); // Raw type instead of ArrayList<>

    public A5() { 
        super();
    }

    public static void main(String[] args) throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter("A5.output"));
        A5Scanner scanner = new A5Scanner(new FileInputStream(new File("A5.tiny")));
        Symbol token;
        boolean hasError = false;

        // Read tokens from the scanner
        while ((token = scanner.next_token()) != null) {
            tokens.add(token);
            if (token.sym == A5Sym.error) {
                hasError = true;
            }
            if (token.sym == A5Sym.EOF) {
                break;
            }
        }

        // Parse the program and check if it ends with EOF
        boolean legal = !hasError && program() && nextToken().sym == A5Sym.EOF;
        bw.write((legal) ? "legal" : "illegal");
        bw.close();
    }

    static Symbol nextToken() {
        if (pointer < tokens.size() - 1) {
            pointer++;
            return (Symbol) tokens.get(pointer); // Cast to Symbol since raw type is used
        } else {
            return null;
        }
    }

    static boolean program() throws Exception {
        int savePointer = pointer;
        if (method() && programTail()) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean programTail() throws Exception {
        int savePointer = pointer;
        if (method() && programTail()) {
            return true;
        }
        pointer = savePointer;
        return true;
    }

    static boolean method() throws Exception {
        int savePointer = pointer;
        if (type() && nextToken().sym == A5Sym.IDENTIFIER && nextToken().sym == A5Sym.LPAREN
                && formalParams() && nextToken().sym == A5Sym.RPAREN && block()) {
            return true;
        }
        pointer = savePointer;
        if (type() && nextToken().sym == A5Sym.MAIN && nextToken().sym == A5Sym.IDENTIFIER
                && nextToken().sym == A5Sym.LPAREN && formalParams()
                && nextToken().sym == A5Sym.RPAREN && block()) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean type() throws Exception {
        Symbol sym = nextToken();
        if (sym.sym == A5Sym.INT || sym.sym == A5Sym.REAL || sym.sym == A5Sym.STRING) {
            return true;
        }
        pointer--;
        return false;
    }

    static boolean formalParams() throws Exception {
        int savePointer = pointer;
        if (formalParam() && FormalParametersTail()) {
            return true;
        }
        pointer = savePointer;
        return true;
    }

    static boolean FormalParametersTail() throws Exception {
        int savePointer = pointer;
        Symbol nextSym = nextToken();
        if (nextSym.sym == A5Sym.COMMA && formalParam() && FormalParametersTail()) {
            return true;
        }
        pointer = savePointer;
        return true;
    }

    static boolean formalParam() throws Exception {
        int savePointer = pointer;
        if (type() && nextToken().sym == A5Sym.IDENTIFIER) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean block() throws Exception {
        int savePointer = pointer;
        if (nextToken().sym == A5Sym.BEGIN && StatementList() && nextToken().sym == A5Sym.END) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean StatementList() throws Exception {
        int savePointer = pointer;
        if (statement() && StatementList()) {
            return true;
        }
        pointer = savePointer;
        return true;
    }

    static boolean statement() throws Exception {
        int savePointer = pointer;
        if (block() || localVarDecl() || AssignmentStatement() || returnStmt() || ifStmt()
                || WriteStatement() || readStmt()) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean AssignmentStatement() throws Exception {
        int savePointer = pointer;
        if (nextToken().sym == A5Sym.IDENTIFIER && nextToken().sym == A5Sym.EQUAL && Expressions()
                && nextToken().sym == A5Sym.SEMI) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean Expressions() throws Exception {
        int savePointer = pointer;
        if (multiplicativeExpression() && expressionTail()) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean expressionTail() throws Exception {
        int savePointer = pointer;
        Symbol sym = nextToken();
        if ((sym.sym == A5Sym.PLUS || sym.sym == A5Sym.MINUS) && multiplicativeExpression()
                && expressionTail()) {
            return true;
        }
        pointer = savePointer;
        return true;
    }

    static boolean multiplicativeExpression() throws Exception {
        int savePointer = pointer;
        if (PrimaryExpressions() && multiplicativeExprTail()) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean multiplicativeExprTail() throws Exception {
        int savePointer = pointer;
        Symbol sym = nextToken();
        if ((sym.sym == A5Sym.MULTI || sym.sym == A5Sym.DIVIDE) && PrimaryExpressions()
                && multiplicativeExprTail()) {
            return true;
        }
        pointer = savePointer;
        return true;
    }

    static boolean PrimaryExpressions() throws Exception {
        int savePointer = pointer;
        if (functionCall()) {
            return true;
        }
        pointer = savePointer;
        Symbol sym = nextToken();
        if (sym.sym == A5Sym.NUMBER || sym.sym == A5Sym.REAL_NUMBER || sym.sym == A5Sym.IDENTIFIER
                || sym.sym == A5Sym.STRING_QUOTE1 || sym.sym == A5Sym.STRING_QUOTE2) {
            return true;
        }
        pointer = savePointer;
        if (nextToken().sym == A5Sym.LPAREN && Expressions() && nextToken().sym == A5Sym.RPAREN) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean functionCall() throws Exception {
        int savePointer = pointer;
        if (nextToken().sym == A5Sym.IDENTIFIER && nextToken().sym == A5Sym.LPAREN
                && ActualParameters() && nextToken().sym == A5Sym.RPAREN) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean ActualParameters() throws Exception {
        int savePointer = pointer;
        if (Expressions() && ActualParametersTails()) {
            return true;
        }
        pointer = savePointer;
        return true;
    }

    static boolean ActualParametersTails() throws Exception {
        int savePointer = pointer;
        Symbol nextSym = nextToken();
        if (nextSym.sym == A5Sym.COMMA && Expressions() && ActualParametersTails()) {
            return true;
        }
        pointer = savePointer;
        return true;
    }

    static boolean localVarDecl() throws Exception {
        int savePointer = pointer;
        if (type() && nextToken().sym == A5Sym.IDENTIFIER && nextToken().sym == A5Sym.SEMI) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean returnStmt() throws Exception {
        int savePointer = pointer;
        if (nextToken().sym == A5Sym.RETURN && Expressions() && nextToken().sym == A5Sym.SEMI) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean WriteStatement() throws Exception {
        int savePointer = pointer;
        if (nextToken().sym == A5Sym.WRITE && nextToken().sym == A5Sym.LPAREN && Expressions()
                && nextToken().sym == A5Sym.COMMA && StringLiteral()
                && nextToken().sym == A5Sym.RPAREN && nextToken().sym == A5Sym.SEMI) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean readStmt() throws Exception {
        int savePointer = pointer;
        if (nextToken().sym == A5Sym.READ && nextToken().sym == A5Sym.LPAREN && nextToken().sym == A5Sym.IDENTIFIER
                && nextToken().sym == A5Sym.COMMA && StringLiteral()
                && nextToken().sym == A5Sym.RPAREN && nextToken().sym == A5Sym.SEMI) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean ifStmt() throws Exception {
        int savePointer = pointer;
        if (nextToken().sym == A5Sym.IF && nextToken().sym == A5Sym.LPAREN
                && BooleanExpression() && nextToken().sym == A5Sym.RPAREN
                && statement()) {
            Symbol nextSym = nextToken();
            if (nextSym.sym == A5Sym.ELSE && statement()) {
                return true;
            }
            pointer--;
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean BooleanExpression() throws Exception {
        int savePointer = pointer;
        Symbol sym = nextToken();
        if (sym.sym == A5Sym.TRUE || sym.sym == A5Sym.FALSE) {
            return true;
        }
        pointer = savePointer;
        if (Expressions() && BooleanOperator() && Expressions()) {
            return true;
        }
        pointer = savePointer;
        return false;
    }

    static boolean BooleanOperator() throws Exception {
        Symbol sym = nextToken();
        if (sym.sym == A5Sym.EQUALS || sym.sym == A5Sym.NOTEQUAL) {
            return true;
        }
        pointer--;
        return false;
    }

    static boolean StringLiteral() throws Exception {
        int savePointer = pointer;
        Symbol sym = nextToken();
        if (sym.sym == A5Sym.STRING_QUOTE1 || sym.sym == A5Sym.STRING_QUOTE2) {
            return true;
        }
        pointer = savePointer;
        return false;
    }
}